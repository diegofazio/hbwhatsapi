-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.11-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para harbourdb
DROP DATABASE IF EXISTS `harbourdb`;
CREATE DATABASE IF NOT EXISTS `harbourdb` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `harbourdb`;

-- Volcando estructura para tabla harbourdb.whatsapp_in
DROP TABLE IF EXISTS `whatsapp_in`;
CREATE TABLE IF NOT EXISTS `whatsapp_in` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `from` text DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `mimetype` text DEFAULT NULL,
  `data` longtext DEFAULT NULL,
  `filename` text DEFAULT NULL,
  `timestamp` int(11) DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1 COMMENT='whatsapp';

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla harbourdb.whatsapp_out
DROP TABLE IF EXISTS `whatsapp_out`;
CREATE TABLE IF NOT EXISTS `whatsapp_out` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `to` text DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `mimetype` text DEFAULT NULL,
  `data` longtext DEFAULT NULL,
  `caption` text DEFAULT NULL,
  `filename` text DEFAULT NULL,
  `timestamp` int(11) DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC COMMENT='whatsapp';

-- La exportación de datos fue deseleccionada.

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
